public static int Get(T value)
{
	if (value == null)
		return 0;
	int hash = 0;
	hash = SelfOuter.Get(value.[Friend]pipelines);
	hash = Mix(hash, value.[Friend]vertexSource);
	hash = Mix(hash, value.[Friend]fragmentSource);
	hash = Mix(hash, value.[Friend]properties);
	hash = Mix(hash, value.[Friend]mClassVData);
	hash = Mix(hash, value.[Friend]mDbgAllocInfo);
	return hash;
}