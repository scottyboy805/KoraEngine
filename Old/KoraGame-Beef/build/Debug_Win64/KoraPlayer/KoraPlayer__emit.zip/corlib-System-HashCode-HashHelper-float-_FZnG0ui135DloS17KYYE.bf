public static int Get(T value)
{
	int hash = 0;
	return hash;
}