public static int Get(T value)
{
	if (value == null)
		return 0;
	int hash = 0;
	hash = SelfOuter.Get(value.[Friend]shader);
	hash = Mix(hash, value.[Friend]renderQueue);
	hash = Mix(hash, value.texture);
	hash = Mix(hash, value.[Friend]game);
	hash = Mix(hash, value.[Friend]name);
	hash = Mix(hash, value.[Friend]mClassVData);
	hash = Mix(hash, value.[Friend]mDbgAllocInfo);
	return hash;
}