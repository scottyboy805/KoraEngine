public static int Get(T value)
{
	return SelfOuter.Get((uint32)value);}