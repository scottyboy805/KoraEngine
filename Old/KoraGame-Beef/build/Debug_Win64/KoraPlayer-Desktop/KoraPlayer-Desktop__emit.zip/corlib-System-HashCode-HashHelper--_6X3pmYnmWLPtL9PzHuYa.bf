public static int Get(T value)
{
	if (value == null)
		return 0;
	int hash = 0;
	return hash;
}