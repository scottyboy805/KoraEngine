public static int Get(T value)
{
	return SelfOuter.Get((int32)value);}